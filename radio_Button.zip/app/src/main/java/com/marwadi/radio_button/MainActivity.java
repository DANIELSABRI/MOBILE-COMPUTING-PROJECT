package com.marwadi.radio_button;

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.RadioGroup

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var radioGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        imageView = findViewById(R.id.imageView)
        radioGroup = findViewById(R.id.radioGroup)

        // Set listener for radio group changes
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
                when (checkedId) {
            R.id.radioButton1 -> imageView.setImageResource(R.drawable.image1)
            R.id.radioButton2 -> imageView.setImageResource(R.drawable.image2)
            R.id.radioButton3 -> imageView.setImageResource(R.drawable.image3)
                else -> { /* Handle unexpected case, though RadioGroup prevents this */ }
        }
        }
    }
}